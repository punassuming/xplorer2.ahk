Menu++ v1.1 by Snakebyte
-------------------------
Menu++ extends Xplorer2 with user customizable menus. Menu++ renders custom menus based on config files. You can create multiple custom menus by passing different configuration file to Menu++

Usage
------
Menu++.exe <CONFIG_FILE_NAME> <$S>

    CONFIG_FILE_NAME is the name of config file containing Menu++ settings. Config files are placed in the same folder as Menu++.exe. Two sample config files are provided for you to play with. Read rest of this document for config file syntax details.

    $S is Xplorer2 'All selected filenames' command line token. Menu++ uses it to determine number of selected files for 'DisableIfNoSelections' option. 


Config File Structure
----------------------
Config file is a text file containing multiple menu entries. Each Menu entry is specified by a Title, Action and DisableIfNoSelections verb. Use empty Title and Action to specify a menu separator. Use # to start a comment line. 

    Example:
        # Sample Menu item that represents 'Invert Selection' menu option
        Title='Invert Selection	Grey *'
        Action=menu,4&,8&
        DisableIfNoSelections=1

        #  Menu separator
        Title=''
        Action=0

Title
------
Title contains the description string of the menu item. Having hotkey string in menu description is optional. Use single tab character to separate Menu description and its associated hotkey.

    Example:
        Title='Hide folders	Alt+J'
        Title='Show All Files'

Note: The hotkey is just for display purpose. Changing it will not actually change the command hotkey.


Action
-------
Whenever a Menu item is clicked, an action is performed. You may associate five different types of actions with a menu click.

    Syntax:
    Action=<CmdID|Menu|Send|Run|Bookmark>, [<Options>...]


1) CmdId: Executes a menu or hotkey command based upon its command id. See Xplorer2 User manual Appendices 9D for command ids or download http://hacks.anunay.com/xplorer2/downloads/Menu_Commands.txt for reference
    Syntax:
        CmdId, <command id>

    Example:
        Action=CmdID,32782              Switch to list view
        Action=CmdID,32783              Switch to detail view


2) Menu: Activates a standard window menu based on name or position.
    Syntax:
        Menu,<rootmenu>[,<submenu>,<submenu>,...]
          or
        Menu,<menuitemposition>&[,<menuitemposition>&,...]

    Example:
        Action=Menu,File,Exit       Activates the File-Exit menu item         or
        Action=Menu,1&,3&           Activates the 1st menu item, then the 3rd menu item. 

Note: While counting menu items positions, count menu separator as well.


3) Send: Sends keys to active window
    Syntax:
            Send,<keypress>[<keypress>...]
    Special keys:
            + = Shift    ^ = Ctrl    ! = Alt    # = Windows key
            See http://www.autohotkey.com/docs/commands/Send.htm for key reference
    Example:
            Action=Send,^!{NumpadAdd}   Sends Ctrl+Alt+Grey+
            Action=Send,^a^c            Send Ctrl-A followed by Ctrl-C to select all and copy.
            Action=Send,^a,^c           Send Ctrl-A followed by Ctrl-C but inserts 50 milliseconds delay between these two commands.


4) Run: Runs a program
    Syntax:
        Run,<path to program> [parameter]
    Example:
        Action=Run,Notepad.exe                  Runs Notepad
        Action=Run,Notepad.exe "C:\temp.txt"    Launches Notepad with additional parameter


5) Bookmark: Opens bookmarked folder in a new tab
    Syntax:
        Bookmark,<folder path>
    Example:
        Action=Bookmark,C:\Windows\System32
        Action=Bookmark,C:\Program Files



DisableIfNoSelections
----------------------
Use this option to disable irrelevant menu options when no items are selected. This menu option is controlled by $S parameter passed to Menu++.
    Syntax:
        DisableIfNoSelections=<1|0>
    Example:
        # Menuitem is only enabled if one or more items are selected in xplorer2
        DisableIfNoSelections=1

        #Menuitem is always enabled irrespective of selected item count in xplorer2
        DisableIfNoSelections=0


Installation
-------------

1. Unzip Menu++.exe, config.ini and display.ini to any folder of your choice. (say C:\My Downloads\Menu++) 

2. Create two user commands in Xplorer2 as 

Name: Menu1 
Description: >"C:\My Downloads\Menu++\Menu++.exe" config.ini $S

Name: Menu2 
Description: >"C:\My Downloads\Menu++\Menu++.exe" display.ini $S

Note: Don't skip ">" symbol at the start of your description. 

3. Add these two commands to your toolbar (Right click on your toolbar and choose customize. Add "Menu1" and "Menu2" commands that you created earlier from left list box to the right one). 
 
4. Now you can use these two toolbar buttons to launch your custom menus. Use the 'Configure...' menu item at the end, to edit the configuration file associated with that particular instance of Menu++.



FAQs
-----
1)  How do I change the default editor that opens the config file?
    - Menu++ launches config file in its default editor. If you launch Menu++ as 
        >"C:\My Downloads\Menu++\Menu++.exe" display.txt
     It will launch config file in default editor associated with .txt files.

2)  Is there a way to access or send x2's batch tokens to the menu commands?
    - Create a user command that uses the x2's batch tokens. Don't add this user command to x2 toolbar, but add it to Menu++ config file instead.
    Example:
        Title='My User Command' 
        Action=Menu,10&,3&,[POSITION_OF_YOUR_USER_COMMAND]& 

3)  As comma is a delimiter character in Menu++, how do I send key strokes that contain comma character?
    - Comma can be passed as ascii to Menu++. Use "{ASC 44}" (Without quotes) instead of comma in your Action=Send verb

Change log
----------
.
[Version - 1.1] 2 June 2007
* Added DisableIfNoSelections option to disable irrelevant menu options when no items are selected
* Added Action=Bookmark verb to open bookmarked folder in a new tab
* When multiple keypress commands(Action=Send verb) are seprated by comma, Menu++ inserts 50 millisecond delay between those commands
* Updated readme with FAQs and other minor changes

[Version - 1.0] 20 Feb 2007
* Initial Release