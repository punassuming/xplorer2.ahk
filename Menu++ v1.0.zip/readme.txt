Menu++ v1.0 by Snakebyte
-------------------------
Menu++ extends Xplorer2 with user customizable menus. Menu++ renders custom menus based on config files. You can create multiple custom menus by passing different configuration file to Menu++

Usage
------
Menu++.exe [CONFIG_FILE_NAME]

NOTE: if CONFIG_FILE_NAME is not specified, Menu++ tries to load the default file named 'config.ini'


Config Files
------------
Config files are placed in the same folder as Menu++.exe. Two sample config files are provided for you to play with with. 

Each Menu entry is specified by a Title and Action line. Use empty Title and Action to specify a menu separator 

Eg.
    Title=''
    Action=0

Title
------

Title contains the description string of the menu item. Having hotkey string in menu description is optional. Use single tab character to separate Menu description and its associated hotkey.

Eg. 
    Title='Hide folders    Alt+J'
    Title='Show All Files'

Note: The hotkey is just for display purpose. Changing it will not actually change the command hotkey.


Action
-------

Whenever a Menu item is clicked, an action is performed. You may associate four different types of actions with a menu click.

    Syntax:
	Action=<CmdID|Menu|Send|Run>, [<Options>...]


1) CmdId: Executes a menu or hotkey command based upon its command id. See Xplorer2 User manual Appendices 9D for command ids or download http://hacks.anunay.com/xplorer2/downloads/Menu_Commands.txt for reference    Syntax:
        CmdId, <command id>

    Example:
        Action=CmdID,32782              Switch to list view
        Action=CmdID,32783              Switch to detail view


2) Menu: Activates a standard window menu based on name or position.
    Syntax:
        Menu,<rootmenu>[,<submenu>,<submenu>,...]
          or
        Menu,<menuitemposition>&[,<menuitemposition>&,...]

    Example:
        Action=Menu,File,Exit       Activates the File-Exit menu item         or
        Action=Menu,1&,3&           Activates the 1st menu item, then the 3rd menu item. 

Note: While counting menu items positions, count menu separator as well.


3) Send: Sends keys to active window
    Syntax:
            Send,<keypress>[<keypress>...]
    Special keys:
            + = Shift    ^ = Ctrl    ! = Alt    # = Windows key
            See http://www.autohotkey.com/docs/commands/Send.htm for key reference
    Example:
            Action=Send,^!{NumpadAdd}   Sends Ctrl+Alt+Grey+
            Action=Send,^a^c            Send Ctrl-A followed by Ctrl-C to select all and copy.


4) Run: Runs a program
    Syntax:
        Run,<path to program> [parameter]
    Example:
        Action=Run,Notepad.exe                  Runs Notepad
        Action=Run,Notepad.exe "C:\temp.txt"    Launches Notepad with additional parameter


Installation
-------------

1. Unzip Menu++.exe, config.ini and display.ini to any folder of your choice. (say C:\My Downloads\Menu++) 

2. Create two user commands in Xplorer2 as 

Name: Menu1 
Description: >"C:\My Downloads\Menu++\Menu++.exe"

Name: Menu2 
Description: >"C:\My Downloads\Menu++\Menu++.exe" display.ini

Note: Don't skip ">" symbol at the start of your description. 

3. Add these two commands to your toolbar (Right click on your toolbar and choose customize. Add "Menu1" and "Menu2" commands that you created earlier from left list box to the right one). 
 
4. Now you can use these two toolbar buttons to launch your custom menus. Use the 'Configure...' menu item at the end, to edit the configuration file associated with that particular instance of Menu++.
